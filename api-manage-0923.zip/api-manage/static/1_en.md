﻿### 1. **First, When SDK is installed(App installed)，this request sends to server, and response a user_id which is saved in phone and used for device id later**

#### GET Request URL：https://superads-sdk-gateway.superadsprod.net/api/meta/user/id
#### Request Headers：empty
#### Request Body：empty

#### Response body：
```
{
    "id": "fd3f0775-9000-412a-be70-374b2d6cfe6f"
}
```