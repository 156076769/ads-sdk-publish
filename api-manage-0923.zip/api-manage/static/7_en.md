### 7. **click url to jump**

#### GET Request URL：https://superads-sdk-gateway.superadsprod.net/api/tracking/click?pbu=xxxxx
#### request headers：empty
#### request body：empty
#### response 200 OK
#### pbu is in get_xxx_ad interface response->eventsUrls->impression, which is base64 encode url.